<?php $__env->startSection('content'); ?>
<div class="row" style="text-align: center">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2> Result </h2>
            </div>
        </div>
    </div>
   
    <div class="row" style="text-align: center;">

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Total Jawaban YA :</strong>
                <label id="yes"><?php echo e($survey->yes); ?></label>
            </div>
        </div>

        <?php if($survey->yes>-1 & $survey->yes<8): ?>         
               <div class="col-xs-12 col-sm-12 col-md-12">
                  <div class="form-group">
                      <strong>Status:</strong>
                      <label id="status">Resiko Rendah</label>
                  </div>
              </div>     
        <?php elseif($survey->yes>7 & $survey->yes<15): ?>
              <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Status :</strong>
                        <label id="status">Resiko Sedang</label>
                    </div>
                </div>     
        <?php else: ?>
            <div class="col-xs-12 col-sm-12 col-md-12">
                  <div class="form-group">
                      <strong>Status :</strong>
                      <label id="status">Resiko Tinggi</label>
                  </div>
              </div>
        <?php endif; ?>

      

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\survey5\resources\views/result.blade.php ENDPATH**/ ?>