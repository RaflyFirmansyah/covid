<?php $__env->startSection('content'); ?>
<div class="main">
    <div class="main-content">
<div class="row" style="text-align: center">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2> Hasil
                 </h2>
            </div>
        </div>
    </div>
    <div class="row" style="text-align: center;">


        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Total Jawaban YA sebanyak :</strong>
                <label id="yes"><?php echo e($survey->yes); ?></label>
            </div>
        </div>

        <?php if($survey->yes>-1 & $survey->yes<8): ?>         
               <div class="col-xs-12 col-sm-12 col-md-12">
                  <div class="form-group">
                      <strong>Status:</strong>
                      <label id="status">Resiko Rendah</label>
                  </div>
              </div>     
        <?php elseif($survey->yes>7 & $survey->yes<15): ?>
              <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Status :</strong>
                        <label id="status">Resiko Sedang</label>
                    </div>
                </div>     
        <?php else: ?>
            <div class="col-xs-12 col-sm-12 col-md-12">
                  <div class="form-group">
                      <strong>Status :</strong>
                      <label id="status">Resiko Tinggi</label>
                  </div>
              </div>
        <?php endif; ?>
        <div class="col-md-12" style="text-align: center;">
          <h2>Terima Kasih</h2>
        </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tescovid\resources\views/result.blade.php ENDPATH**/ ?>